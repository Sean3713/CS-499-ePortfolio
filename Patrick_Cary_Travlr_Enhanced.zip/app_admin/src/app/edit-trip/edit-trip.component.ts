import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';

import { Trip } from '../models/trip';
import { TripDataService } from '../services/trip-data.service';

@Component({
  selector: 'app-edit-trip',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './edit-trip.component.html',
  styleUrl: './edit-trip.component.css'
})
export class EditTripComponent implements OnInit {
  originalCode = '';

  trip: Trip = {
    _id: '',
    code: '',
    name: '',
    length: '',
    start: '',
    resort: '',
    perPerson: '',
    image: '',
    description: ''
  };

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private tripDataService: TripDataService
  ) {}

  ngOnInit(): void {
    this.originalCode = this.route.snapshot.paramMap.get('tripCode') || '';

    this.tripDataService.getTrip(this.originalCode).subscribe({
      next: (trip: Trip) => {
        this.trip = trip;
        this.trip.start = this.trip.start.substring(0, 10);
      },
      error: (error) => {
        console.error('Unable to retrieve trip:', error);
      }
    });
  }

  updateTrip(): void {
    this.tripDataService.updateTrip(this.originalCode, this.trip).subscribe({
      next: () => {
        this.router.navigate(['/']);
      },
      error: (error) => {
        console.error('Unable to update trip:', error);
      }
    });
  }
}
