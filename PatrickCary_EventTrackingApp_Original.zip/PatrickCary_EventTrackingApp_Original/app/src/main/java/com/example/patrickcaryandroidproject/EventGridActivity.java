package com.example.patrickcaryandroidproject;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;

import androidx.appcompat.app.AppCompatActivity;

// This screen lets the user create, read, update, and delete events.
public class EventGridActivity extends AppCompatActivity {

    private EditText editEventId;
    private EditText editEventName;
    private EditText editEventDate;
    private EditText editEventDescription;
    private Button buttonAddEvent;
    private Button buttonViewEvents;
    private Button buttonUpdateEvent;
    private Button buttonDeleteEvent;
    private TextView textEventList;
    private DatabaseHelper databaseHelper;
    private Button buttonSmsSettings;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_grid);

        databaseHelper = new DatabaseHelper(this);

        editEventId = findViewById(R.id.editEventId);
        editEventName = findViewById(R.id.editEventName);
        editEventDate = findViewById(R.id.editEventDate);
        editEventDescription = findViewById(R.id.editEventDescription);

        buttonAddEvent = findViewById(R.id.buttonAddEvent);
        buttonViewEvents = findViewById(R.id.buttonViewEvents);
        buttonUpdateEvent = findViewById(R.id.buttonUpdateEvent);
        buttonDeleteEvent = findViewById(R.id.buttonDeleteEvent);
        buttonSmsSettings = findViewById(R.id.buttonSmsSettings);

        textEventList = findViewById(R.id.textEventList);

        buttonAddEvent.setOnClickListener(view -> addEvent());
        buttonViewEvents.setOnClickListener(view -> viewEvents());
        buttonUpdateEvent.setOnClickListener(view -> updateEvent());
        buttonDeleteEvent.setOnClickListener(view -> deleteEvent());
        buttonSmsSettings.setOnClickListener(view -> {
            Intent intent = new Intent(EventGridActivity.this, SmsPermissionActivity.class);
            startActivity(intent);
        });
    }

    // Adds a new event to the database.
    private void addEvent() {
        String name = editEventName.getText().toString().trim();
        String date = editEventDate.getText().toString().trim();
        String description = editEventDescription.getText().toString().trim();

        if (name.isEmpty() || date.isEmpty() || description.isEmpty()) {
            Toast.makeText(this, "Please enter event name, date, and description.", Toast.LENGTH_SHORT).show();
        } else {
            boolean inserted = databaseHelper.addEvent(name, date, description);

            if (inserted) {
                Toast.makeText(this, "Event added.", Toast.LENGTH_SHORT).show();
                clearInputs();
                viewEvents();
            } else {
                Toast.makeText(this, "Event could not be added.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // Shows all events from the database.
    private void viewEvents() {
        Cursor cursor = databaseHelper.getAllEvents();

        if (cursor.getCount() == 0) {
            textEventList.setText("No events found.");
            cursor.close();
            return;
        }

        StringBuilder builder = new StringBuilder();

        while (cursor.moveToNext()) {
            builder.append("ID: ").append(cursor.getInt(0)).append("\n");
            builder.append("Event: ").append(cursor.getString(1)).append("\n");
            builder.append("Date: ").append(cursor.getString(2)).append("\n");
            builder.append("Description: ").append(cursor.getString(3)).append("\n\n");
        }

        textEventList.setText(builder.toString());
        cursor.close();
    }

    // Updates an event by using its ID number.
    private void updateEvent() {
        String idText = editEventId.getText().toString().trim();
        String name = editEventName.getText().toString().trim();
        String date = editEventDate.getText().toString().trim();
        String description = editEventDescription.getText().toString().trim();

        if (idText.isEmpty() || name.isEmpty() || date.isEmpty() || description.isEmpty()) {
            Toast.makeText(this, "Please enter ID, name, date, and description.", Toast.LENGTH_SHORT).show();
        } else {
            int id = Integer.parseInt(idText);
            boolean updated = databaseHelper.updateEvent(id, name, date, description);

            if (updated) {
                Toast.makeText(this, "Event updated.", Toast.LENGTH_SHORT).show();
                clearInputs();
                viewEvents();
            } else {
                Toast.makeText(this, "Event not found.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // Deletes an event by using its ID number.
    private void deleteEvent() {
        String idText = editEventId.getText().toString().trim();

        if (idText.isEmpty()) {
            Toast.makeText(this, "Please enter the event ID.", Toast.LENGTH_SHORT).show();
        } else {
            int id = Integer.parseInt(idText);
            boolean deleted = databaseHelper.deleteEvent(id);

            if (deleted) {
                Toast.makeText(this, "Event deleted.", Toast.LENGTH_SHORT).show();
                clearInputs();
                viewEvents();
            } else {
                Toast.makeText(this, "Event not found.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // Clears the typing boxes after an action is finished.
    private void clearInputs() {
        editEventId.setText("");
        editEventName.setText("");
        editEventDate.setText("");
        editEventDescription.setText("");
    }
}