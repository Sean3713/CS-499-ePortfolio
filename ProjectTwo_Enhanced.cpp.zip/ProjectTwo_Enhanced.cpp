#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <unordered_map>
#include <algorithm>
#include <chrono>
#include <cctype>

using namespace std;

// Stores the information for one course.
struct Course {
    string courseNumber;
    string courseTitle;
    vector<string> prerequisites;
};

// Converts course numbers to uppercase so searches are consistent.
string toUpperCase(string text) {
    transform(text.begin(), text.end(), text.begin(),
              [](unsigned char c) {
                  return static_cast<char>(toupper(c));
              });
    return text;
}

// Removes spaces from the beginning and end of a string.
string trim(const string& text) {
    size_t first = text.find_first_not_of(" \t\r\n");

    if (first == string::npos) {
        return "";
    }

    size_t last = text.find_last_not_of(" \t\r\n");
    return text.substr(first, last - first + 1);
}

// Node used by the Binary Search Tree.
struct TreeNode {
    Course course;
    TreeNode* left;
    TreeNode* right;

    TreeNode(const Course& newCourse)
        : course(newCourse), left(nullptr), right(nullptr) {
    }
};

// Binary Search Tree used to store courses by course number.
class CourseBST {
private:
    TreeNode* root;

    // Inserts a course recursively.
    TreeNode* insert(TreeNode* node, const Course& course) {
        if (node == nullptr) {
            return new TreeNode(course);
        }

        if (course.courseNumber < node->course.courseNumber) {
            node->left = insert(node->left, course);
        } else if (course.courseNumber > node->course.courseNumber) {
            node->right = insert(node->right, course);
        } else {
            // If the course already exists, update its information.
            node->course = course;
        }

        return node;
    }

    // Searches the tree recursively.
    const Course* search(TreeNode* node, const string& courseNumber) const {
        if (node == nullptr) {
            return nullptr;
        }

        if (courseNumber == node->course.courseNumber) {
            return &node->course;
        }

        if (courseNumber < node->course.courseNumber) {
            return search(node->left, courseNumber);
        }

        return search(node->right, courseNumber);
    }

    // Prints the courses in alphanumeric order.
    void inOrder(TreeNode* node) const {
        if (node == nullptr) {
            return;
        }

        inOrder(node->left);

        cout << node->course.courseNumber
             << ", "
             << node->course.courseTitle
             << endl;

        inOrder(node->right);
    }

    // Deletes tree nodes when the program ends or reloads data.
    void destroy(TreeNode* node) {
        if (node == nullptr) {
            return;
        }

        destroy(node->left);
        destroy(node->right);
        delete node;
    }

public:
    CourseBST() : root(nullptr) {
    }

    ~CourseBST() {
        destroy(root);
    }

    void insert(const Course& course) {
        root = insert(root, course);
    }

    const Course* search(const string& courseNumber) const {
        return search(root, courseNumber);
    }

    void printInOrder() const {
        inOrder(root);
    }

    void clear() {
        destroy(root);
        root = nullptr;
    }
};

// Searches the vector using a linear search.
const Course* searchVector(const vector<Course>& courses,
                           const string& courseNumber) {
    for (const Course& course : courses) {
        if (course.courseNumber == courseNumber) {
            return &course;
        }
    }

    return nullptr;
}

// Loads course data into three different data structures.
bool loadCourses(const string& filename,
                 vector<Course>& courses,
                 unordered_map<string, Course>& courseMap,
                 CourseBST& courseTree) {

    ifstream file(filename);

    if (!file.is_open()) {
        cerr << "Error: file could not be opened: "
             << filename << endl;
        return false;
    }

    courses.clear();
    courseMap.clear();
    courseTree.clear();

    string line;
    int loadedCount = 0;
    int skippedCount = 0;

    while (getline(file, line)) {
        line = trim(line);

        if (line.empty()) {
            continue;
        }

        stringstream ss(line);

        string courseNumber;
        string courseTitle;
        string prerequisite;

        getline(ss, courseNumber, ',');
        getline(ss, courseTitle, ',');

        courseNumber = toUpperCase(trim(courseNumber));
        courseTitle = trim(courseTitle);

        // Skip records that do not contain required information.
        if (courseNumber.empty() || courseTitle.empty()) {
            ++skippedCount;
            continue;
        }

        Course course;
        course.courseNumber = courseNumber;
        course.courseTitle = courseTitle;

        while (getline(ss, prerequisite, ',')) {
            prerequisite = toUpperCase(trim(prerequisite));

            if (!prerequisite.empty()) {
                course.prerequisites.push_back(prerequisite);
            }
        }

        courses.push_back(course);
        courseMap[course.courseNumber] = course;
        courseTree.insert(course);

        ++loadedCount;
    }

    file.close();

    cout << loadedCount << " courses loaded successfully." << endl;

    if (skippedCount > 0) {
        cout << skippedCount
             << " invalid record(s) were skipped."
             << endl;
    }

    return loadedCount > 0;
}

// Prints one course and its prerequisites.
void printCourseInfo(const Course& course) {
    cout << endl;
    cout << course.courseNumber
         << ", "
         << course.courseTitle
         << endl;

    cout << "Prerequisites: ";

    if (course.prerequisites.empty()) {
        cout << "None";
    } else {
        for (size_t i = 0;
             i < course.prerequisites.size();
             ++i) {

            cout << course.prerequisites[i];

            if (i < course.prerequisites.size() - 1) {
                cout << ", ";
            }
        }
    }

    cout << endl;
}

// Compares searches performed with three data structures.
void compareDataStructures(
    const vector<Course>& courses,
    const unordered_map<string, Course>& courseMap,
    const CourseBST& courseTree,
    const string& courseNumber) {

    cout << endl;
    cout << "Data Structure Search Comparison" << endl;
    cout << "--------------------------------" << endl;

    // Vector linear search.
    auto vectorStart =
        chrono::high_resolution_clock::now();

    const Course* vectorResult =
        searchVector(courses, courseNumber);

    auto vectorEnd =
        chrono::high_resolution_clock::now();

    // Unordered map search.
    auto mapStart =
        chrono::high_resolution_clock::now();

    auto mapResult =
        courseMap.find(courseNumber);

    auto mapEnd =
        chrono::high_resolution_clock::now();

    // Binary search tree search.
    auto treeStart =
        chrono::high_resolution_clock::now();

    const Course* treeResult =
        courseTree.search(courseNumber);

    auto treeEnd =
        chrono::high_resolution_clock::now();

    auto vectorTime =
        chrono::duration_cast<chrono::nanoseconds>(
            vectorEnd - vectorStart).count();

    auto mapTime =
        chrono::duration_cast<chrono::nanoseconds>(
            mapEnd - mapStart).count();

    auto treeTime =
        chrono::duration_cast<chrono::nanoseconds>(
            treeEnd - treeStart).count();

    cout << "Vector linear search: "
         << vectorTime << " nanoseconds" << endl;

    cout << "Unordered map search: "
         << mapTime << " nanoseconds" << endl;

    cout << "Binary search tree search: "
         << treeTime << " nanoseconds" << endl;

    cout << endl;

    cout << "Vector result: "
         << (vectorResult != nullptr ? "Found" : "Not found")
         << endl;

    cout << "Unordered map result: "
         << (mapResult != courseMap.end()
                 ? "Found"
                 : "Not found")
         << endl;

    cout << "Binary search tree result: "
         << (treeResult != nullptr ? "Found" : "Not found")
         << endl;

    cout << endl;
    cout << "Expected complexity:" << endl;
    cout << "Vector search: O(n)" << endl;
    cout << "Unordered map search: O(1) average" << endl;
    cout << "Binary search tree search: O(log n) average"
         << endl;

    cout << endl;
    cout << "Note: Actual timing can vary because this "
         << "course data set is small."
         << endl;
}

int main() {
    vector<Course> courses;
    unordered_map<string, Course> courseMap;
    CourseBST courseTree;

    string filename;
    string courseNumber;

    bool dataLoaded = false;

    cout << "Welcome to the course planner." << endl;

    while (true) {
        cout << endl;
        cout << "1. Load Data Structure" << endl;
        cout << "2. Print Course List" << endl;
        cout << "3. Print Course" << endl;
        cout << "4. Compare Data Structures" << endl;
        cout << "9. Exit" << endl;
        cout << "What would you like to do? ";

        string choiceText;
        getline(cin, choiceText);

        int choice;

        try {
            choice = stoi(choiceText);
        } catch (...) {
            cout << "Please enter a valid menu option."
                 << endl;
            continue;
        }

        switch (choice) {

            case 1: {
                cout << "Enter the file name: ";
                getline(cin, filename);

                dataLoaded =
                    loadCourses(filename,
                                courses,
                                courseMap,
                                courseTree);

                break;
            }

            case 2: {
                if (!dataLoaded) {
                    cout << "Please load the course data first."
                         << endl;
                    break;
                }

                cout << endl;
                cout << "Here is a sample schedule:"
                     << endl;
                cout << endl;

                // In-order traversal automatically prints
                // courses in alphanumeric order.
                courseTree.printInOrder();

                break;
            }

            case 3: {
                if (!dataLoaded) {
                    cout << "Please load the course data first."
                         << endl;
                    break;
                }

                cout << "What course do you want to know about? ";
                getline(cin, courseNumber);

                courseNumber =
                    toUpperCase(trim(courseNumber));

                // Use the Binary Search Tree for retrieval.
                const Course* course =
                    courseTree.search(courseNumber);

                if (course != nullptr) {
                    printCourseInfo(*course);
                } else {
                    cout << "Course "
                         << courseNumber
                         << " was not found."
                         << endl;
                }

                break;
            }

            case 4: {
                if (!dataLoaded) {
                    cout << "Please load the course data first."
                         << endl;
                    break;
                }

                cout << "Enter a course number to compare: ";
                getline(cin, courseNumber);

                courseNumber =
                    toUpperCase(trim(courseNumber));

                compareDataStructures(
                    courses,
                    courseMap,
                    courseTree,
                    courseNumber);

                break;
            }

            case 9:
                cout << "Thank you for using the course planner!"
                     << endl;
                return 0;

            default:
                cout << choice
                     << " is not a valid option."
                     << endl;
                break;
        }
    }

    return 0;
}
