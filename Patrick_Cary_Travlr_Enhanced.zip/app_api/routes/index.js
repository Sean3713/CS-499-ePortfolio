const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');

const tripsController = require('../controllers/trips');
const authController = require('../controllers/authentication');

// Authenticates JWTs before allowing protected database operations.
function authenticateJWT(req, res, next) {
    const authHeader = req.headers.authorization;

    if (!authHeader) {
        return res.status(401).json({
            message: 'Authorization header is required.'
        });
    }

    const parts = authHeader.split(' ');

    if (parts.length !== 2 || parts[0] !== 'Bearer') {
        return res.status(401).json({
            message: 'Authorization header must use Bearer token format.'
        });
    }

    const token = parts[1];

    if (!token) {
        return res.status(401).json({
            message: 'Authentication token is required.'
        });
    }

    if (!process.env.JWT_SECRET) {
        return res.status(500).json({
            message: 'Authentication configuration error.'
        });
    }

    jwt.verify(token, process.env.JWT_SECRET, (err, verified) => {
        if (err) {
            return res.status(401).json({
                message: 'Invalid or expired authentication token.'
            });
        }

        req.auth = verified;
        next();
    });
}


// Trip collection routes.
// Reading trip information remains public.
// Creating a trip requires authentication.
router
    .route('/trips')
    .get(tripsController.tripsList)
    .post(authenticateJWT, tripsController.tripsAddTrip);


// Individual trip routes.
// Reading remains public.
// Updating and deleting require authentication.
router
    .route('/trips/:tripCode')
    .get(tripsController.tripsFindByCode)
    .put(authenticateJWT, tripsController.tripsUpdateTrip)
    .delete(authenticateJWT, tripsController.tripsDeleteTrip);


// Register endpoint.
router
    .route('/register')
    .post(authController.register);


// Login endpoint.
router
    .route('/login')
    .post(authController.login);


module.exports = router;
