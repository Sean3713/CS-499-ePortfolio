#include <iostream>
//insert fstream to open file
#include <fstream>
#include <sstream>
#include <vector>
#include <algorithm>
#include <unordered_map>

using namespace std;

struct Course {
	string courseNumber;
	string courseTitle;
	vector<string> prerequisities;
};

void loadCourses(const string& filename, vector<Course>& courses,
	unordered_map<string, Course>& courseMap) {
	//call to open file
	ifstream file(filename);
	if (!file.is_open()) {
		cerr << "Error, file not found " << filename << endl;
		return;
	}

	string line;
	//insert while loop
	while (getline(file, line)) {
		stringstream ss(line);
		string courseNumber, courseTitle, prereq;
		getline(ss, courseNumber, ',');
		getline(ss, courseTitle, ',');

		Course course;
		course.courseNumber = courseNumber;
		course.courseTitle = courseTitle;

		//insert while loop for pre-req
		while (getline(ss.prereq, ',')) {
			course.prerequisities.push_back(prereq);
		}

		courses.push_back(course);
		courseMap[courseNumber] = course;
	}

	//close file
	file.close();
}
//insert int main to return an integer value
int main() {
	vector<Course> courses;
	unordered_map<string, Course>, courseMap;
	int choice;
	string filename, courseNumber;
	//add welcome to user
	cout << "Welcome to the course planner." << endl;

	while (true) {
		cout << "1. Load Data Structure." << endl;
		cout << "2. Print Course List." << endl;
		cout << "3. Print Course." << endl;
		cout << "9. Exit" << endl;
		cout << "What would you like to do? ";
		cin >> choice;

		//insert switch statements for multiple choices
		switch (choice) {
		case 1:
			cout << "Enter the file name: ";
			cin >> filename;
			loadCourses(filename, courses, courseMap);
			sort(courses.begin(), courses.end(), [](const Course& a, const Course& b) {
				return a.courseNumber < b.courseNumber;
				});
			break;

		case 2:
			printCourseList(courses);
			break;

		case 3:
			cout << "What course do you want to know about? ";
			cin >> courseNumber;
			printCourseInfo(courseMap, courseNumber);
			break;

		case 9:
			cout << "Thank you for using the course planner!" << endl;
			return 0;

		default:
			cout << choice << " is not a valid option." << endl;
			break;
		}

	}
	//execute program with return 0;
	return 0;
}

