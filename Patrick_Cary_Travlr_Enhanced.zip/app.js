require('dotenv').config();
console.log('Step 1');

const express = require('express');
const path = require('path');
const handlebars = require('hbs');
console.log('Step 1.5');

require('./app_server/models/db');
console.log('Step 2');

const indexRouter = require('./app_server/routes/index');
const travelRouter = require('./app_server/routes/travel');
const apiRouter = require('./app_api/routes/index');
console.log('Step 3');

const passport = require('passport');
require('./app_api/config/passport');

const app = express();
const PORT = 3000;

// Read JSON and form data
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// Handlebars view engine setup
app.set('views', path.join(__dirname, 'app_server', 'views'));
app.set('view engine', 'hbs');

// Register Handlebars partials
handlebars.registerPartials(
  path.join(__dirname, 'app_server', 'views', 'partials')
);

// Allow the Angular admin app to access the API
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', 'http://localhost:4200');
  res.header(
    'Access-Control-Allow-Headers',
    'Origin, X-Requested-With, Content-Type, Accept, Authorization'
  );
  res.header(
    'Access-Control-Allow-Methods',
    'GET, POST, PUT, DELETE, OPTIONS'
  );

  if (req.method === 'OPTIONS') {
    return res.sendStatus(200);
  }

  next();
});

// Serve static files from the public folder
app.use(express.static(path.join(__dirname, 'public')));
app.use(passport.initialize());

console.log('Reached routes section');

// Register routes
app.use('/', indexRouter);
app.use('/travel', travelRouter);
app.use('/api', apiRouter);

// Start the server
console.log('Reached app.listen section');

// Catch unauthorized error and create 401
app.use((err, req, res, next) => {
  if (err.name === 'UnauthorizedError') {
    res
      .status(401)
      .json({ message: err.name + ': ' + err.message });
  }
});

app.listen(PORT, () => {
  console.log(`Travlr Getaways app is running at http://localhost:${PORT}`);
});