const mongoose = require('mongoose');

// Define the trip schema with stronger validation.
const tripSchema = new mongoose.Schema(
  {
    code: {
      type: String,
      required: [true, 'Trip code is required.'],
      trim: true,
      uppercase: true,
      minlength: [2, 'Trip code must contain at least 2 characters.'],
      maxlength: [20, 'Trip code cannot exceed 20 characters.'],
      unique: true,
      index: true
    },

    name: {
      type: String,
      required: [true, 'Trip name is required.'],
      trim: true,
      minlength: [2, 'Trip name must contain at least 2 characters.'],
      maxlength: [100, 'Trip name cannot exceed 100 characters.'],
      index: true
    },

    length: {
      type: String,
      required: [true, 'Trip length is required.'],
      trim: true,
      maxlength: [50, 'Trip length cannot exceed 50 characters.']
    },

    start: {
      type: Date,
      required: [true, 'Trip start date is required.']
    },

    resort: {
      type: String,
      required: [true, 'Resort is required.'],
      trim: true,
      minlength: [2, 'Resort must contain at least 2 characters.'],
      maxlength: [100, 'Resort cannot exceed 100 characters.']
    },

    perPerson: {
      type: String,
      required: [true, 'Price per person is required.'],
      trim: true,
      validate: {
        validator: function (value) {
          return /^[\$]?\d+(\.\d{1,2})?$/.test(value);
        },
        message: 'Price per person must be a valid monetary amount.'
      }
    },

    image: {
      type: String,
      required: [true, 'Trip image is required.'],
      trim: true,
      maxlength: [255, 'Image path cannot exceed 255 characters.']
    },

    description: {
      type: String,
      required: [true, 'Trip description is required.'],
      trim: true,
      minlength: [10, 'Trip description must contain at least 10 characters.'],
      maxlength: [1000, 'Trip description cannot exceed 1000 characters.']
    }
  },
  {
    versionKey: false
  }
);

// Additional indexes improve common database searches and filtering.
tripSchema.index({ resort: 1, start: 1 });
tripSchema.index({ start: 1 });

const Trip = mongoose.model('trips', tripSchema);

module.exports = Trip;
