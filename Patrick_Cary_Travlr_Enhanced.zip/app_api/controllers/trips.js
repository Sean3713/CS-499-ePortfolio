const Trip = require('../models/travlr');

// Converts trip codes to the same format used by the schema.
const normalizeTripCode = (code = '') => {
    return code.trim().toUpperCase();
};

// Only allows approved trip fields to be written to the database.
const buildTripData = (body) => ({
    code: body.code,
    name: body.name,
    length: body.length,
    start: body.start,
    resort: body.resort,
    perPerson: body.perPerson,
    image: body.image,
    description: body.description
});

// Returns a safe validation response without exposing unnecessary details.
const handleDatabaseError = (res, err, defaultMessage) => {
    if (err && err.code === 11000) {
        return res.status(409).json({
            message: 'A trip with that code already exists.'
        });
    }

    if (err && err.name === 'ValidationError') {
        const errors = Object.values(err.errors).map(
            (error) => error.message
        );

        return res.status(400).json({
            message: 'Trip validation failed.',
            errors
        });
    }

    return res.status(500).json({
        message: defaultMessage
    });
};


// GET: /api/trips
// Supports efficient filtering by resort and start date.
const tripsList = async (req, res) => {
    try {
        const filter = {};

        if (req.query.resort) {
            filter.resort = req.query.resort.trim();
        }

        if (req.query.startDate || req.query.endDate) {
            filter.start = {};

            if (req.query.startDate) {
                const startDate = new Date(req.query.startDate);

                if (Number.isNaN(startDate.getTime())) {
                    return res.status(400).json({
                        message: 'Invalid startDate value.'
                    });
                }

                filter.start.$gte = startDate;
            }

            if (req.query.endDate) {
                const endDate = new Date(req.query.endDate);

                if (Number.isNaN(endDate.getTime())) {
                    return res.status(400).json({
                        message: 'Invalid endDate value.'
                    });
                }

                filter.start.$lte = endDate;
            }
        }

        // lean() improves read performance when Mongoose documents
        // do not need to be modified.
        const trips = await Trip.find(filter)
            .sort({ start: 1 })
            .lean()
            .exec();

        if (!trips || trips.length === 0) {
            return res.status(404).json({
                message: 'No trips found.'
            });
        }

        return res.status(200).json(trips);

    } catch (err) {
        return res.status(500).json({
            message: 'Unable to retrieve trips.'
        });
    }
};


// GET: /api/trips/:tripCode
const tripsFindByCode = async (req, res) => {
    try {
        const tripCode = normalizeTripCode(req.params.tripCode);

        if (!tripCode) {
            return res.status(400).json({
                message: 'Trip code is required.'
            });
        }

        const trip = await Trip.findOne({ code: tripCode })
            .lean()
            .exec();

        if (!trip) {
            return res.status(404).json({
                message: `Trip ${tripCode} not found.`
            });
        }

        return res.status(200).json(trip);

    } catch (err) {
        return res.status(500).json({
            message: 'Unable to retrieve trip.'
        });
    }
};


// POST: /api/trips
const tripsAddTrip = async (req, res) => {
    try {
        const tripData = buildTripData(req.body);

        if (tripData.code) {
            tripData.code = normalizeTripCode(tripData.code);
        }

        const newTrip = await Trip.create(tripData);

        return res.status(201).json(newTrip);

    } catch (err) {
        return handleDatabaseError(
            res,
            err,
            'Unable to create trip.'
        );
    }
};


// PUT: /api/trips/:tripCode
const tripsUpdateTrip = async (req, res) => {
    try {
        const tripCode = normalizeTripCode(req.params.tripCode);

        if (!tripCode) {
            return res.status(400).json({
                message: 'Trip code is required.'
            });
        }

        const tripData = buildTripData(req.body);

        if (tripData.code) {
            tripData.code = normalizeTripCode(tripData.code);
        }

        const updatedTrip = await Trip.findOneAndUpdate(
            { code: tripCode },
            tripData,
            {
                new: true,
                runValidators: true
            }
        ).exec();

        if (!updatedTrip) {
            return res.status(404).json({
                message: `Trip ${tripCode} not found.`
            });
        }

        return res.status(200).json(updatedTrip);

    } catch (err) {
        return handleDatabaseError(
            res,
            err,
            'Unable to update trip.'
        );
    }
};


// DELETE: /api/trips/:tripCode
const tripsDeleteTrip = async (req, res) => {
    try {
        const tripCode = normalizeTripCode(req.params.tripCode);

        if (!tripCode) {
            return res.status(400).json({
                message: 'Trip code is required.'
            });
        }

        const deletedTrip = await Trip.findOneAndDelete({
            code: tripCode
        }).exec();

        if (!deletedTrip) {
            return res.status(404).json({
                message: `Trip ${tripCode} not found.`
            });
        }

        return res.status(204).send();

    } catch (err) {
        return res.status(500).json({
            message: 'Unable to delete trip.'
        });
    }
};


module.exports = {
    tripsList,
    tripsFindByCode,
    tripsAddTrip,
    tripsUpdateTrip,
    tripsDeleteTrip
};
