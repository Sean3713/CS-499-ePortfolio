package com.example.patrickcaryandroidproject;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

// This screen asks the user for SMS permission and sends event alerts if allowed.
public class SmsPermissionActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 100;

    private EditText editPhoneNumber;
    private Button buttonRequestPermission;
    private Button buttonSendAlert;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_permission);

        editPhoneNumber = findViewById(R.id.editPhoneNumber);
        buttonRequestPermission = findViewById(R.id.buttonRequestPermission);
        buttonSendAlert = findViewById(R.id.buttonSendAlert);

        buttonRequestPermission.setOnClickListener(view -> requestSmsPermission());
        buttonSendAlert.setOnClickListener(view -> sendSmsAlert());
    }

    // Requests permission from the user to send SMS messages.
    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "SMS permission already granted.", Toast.LENGTH_SHORT).show();
        } else {
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_CODE
            );
        }
    }

    // Sends a simple event alert if SMS permission was granted.
    private void sendSmsAlert() {
        String phoneNumber = editPhoneNumber.getText().toString().trim();

        if (phoneNumber.isEmpty()) {
            Toast.makeText(this, "Please enter a phone number.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(
                    phoneNumber,
                    null,
                    "Event Tracker Alert: You have an upcoming event.",
                    null,
                    null
            );

            Toast.makeText(this, "SMS alert sent.", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "SMS permission denied. App still works without SMS.", Toast.LENGTH_LONG).show();
        }
    }

    // Handles the user's answer to the permission request.
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS permission granted.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "SMS permission denied. The rest of the app will still work.", Toast.LENGTH_LONG).show();
            }
        }
    }
}