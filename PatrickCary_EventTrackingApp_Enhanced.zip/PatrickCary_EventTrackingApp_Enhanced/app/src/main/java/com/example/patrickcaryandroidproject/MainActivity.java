package com.example.patrickcaryandroidproject;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

// This screen allows the user to log in or create a new account.
public class MainActivity extends AppCompatActivity {

    private EditText editUsername;
    private EditText editPassword;

    private Button buttonLogin;
    private Button buttonCreateAccount;

    private DatabaseHelper databaseHelper;

    private static final int MIN_USERNAME_LENGTH = 3;
    private static final int MIN_PASSWORD_LENGTH = 8;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Connect Java variables to the XML screen items.
        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);

        buttonLogin = findViewById(R.id.buttonLogin);
        buttonCreateAccount = findViewById(R.id.buttonCreateAccount);

        // Create the database helper object.
        databaseHelper = new DatabaseHelper(this);

        buttonLogin.setOnClickListener(view -> loginUser());

        buttonCreateAccount.setOnClickListener(view -> createAccount());
    }

    // Checks the user's credentials and opens the event screen.
    private void loginUser() {

        String username =
                editUsername.getText().toString().trim();

        String password =
                editPassword.getText().toString();

        if (username.isEmpty() || password.isEmpty()) {

            Toast.makeText(
                    this,
                    "Please enter a username and password.",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        boolean userExists =
                databaseHelper.checkUser(
                        username,
                        password
                );

        if (userExists) {

            Toast.makeText(
                    this,
                    "Login successful.",
                    Toast.LENGTH_SHORT
            ).show();

            editPassword.setText("");

            Intent intent =
                    new Intent(
                            MainActivity.this,
                            EventGridActivity.class
                    );

            startActivity(intent);

        } else {

            Toast.makeText(
                    this,
                    "Incorrect username or password.",
                    Toast.LENGTH_SHORT
            ).show();

            editPassword.setText("");
        }
    }

    // Creates a new account after validating the username and password.
    private void createAccount() {

        String username =
                editUsername.getText().toString().trim();

        String password =
                editPassword.getText().toString();

        if (!validateNewAccount(username, password)) {
            return;
        }

        boolean accountCreated =
                databaseHelper.addUser(
                        username,
                        password
                );

        if (accountCreated) {

            Toast.makeText(
                    this,
                    "Account created. You can now log in.",
                    Toast.LENGTH_SHORT
            ).show();

            editPassword.setText("");

        } else {

            Toast.makeText(
                    this,
                    "Username already exists or account could not be created.",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    // Validates account information before it is saved.
    private boolean validateNewAccount(
            String username,
            String password) {

        if (username.isEmpty() || password.isEmpty()) {

            Toast.makeText(
                    this,
                    "Please enter a username and password.",
                    Toast.LENGTH_SHORT
            ).show();

            return false;
        }

        if (username.length() < MIN_USERNAME_LENGTH) {

            Toast.makeText(
                    this,
                    "Username must be at least 3 characters.",
                    Toast.LENGTH_SHORT
            ).show();

            return false;
        }

        if (password.length() < MIN_PASSWORD_LENGTH) {

            Toast.makeText(
                    this,
                    "Password must be at least 8 characters.",
                    Toast.LENGTH_SHORT
            ).show();

            return false;
        }

        if (!containsLetter(password)
                || !containsNumber(password)) {

            Toast.makeText(
                    this,
                    "Password must contain at least one letter and one number.",
                    Toast.LENGTH_SHORT
            ).show();

            return false;
        }

        return true;
    }

    // Checks whether the password contains a letter.
    private boolean containsLetter(String password) {

        for (char character : password.toCharArray()) {

            if (Character.isLetter(character)) {
                return true;
            }
        }

        return false;
    }

    // Checks whether the password contains a number.
    private boolean containsNumber(String password) {

        for (char character : password.toCharArray()) {

            if (Character.isDigit(character)) {
                return true;
            }
        }

        return false;
    }
}