package com.example.patrickcaryandroidproject;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

// This class creates and manages the SQLite database for users and events.
public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "EventTracker.db";
    private static final int DATABASE_VERSION = 2;

    // User table
    private static final String TABLE_USERS = "users";
    private static final String USER_ID = "id";
    private static final String USERNAME = "username";
    private static final String PASSWORD = "password";

    // Event table
    private static final String TABLE_EVENTS = "events";
    private static final String EVENT_ID = "id";
    private static final String EVENT_NAME = "event_name";
    private static final String EVENT_DATE = "event_date";
    private static final String EVENT_DESCRIPTION = "event_description";
    private static final String EVENT_CATEGORY = "event_category";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Creates the database tables when the app first runs.
    @Override
    public void onCreate(SQLiteDatabase db) {

        String createUsersTable = "CREATE TABLE " + TABLE_USERS + " (" +
                USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                USERNAME + " TEXT UNIQUE NOT NULL, " +
                PASSWORD + " TEXT NOT NULL)";

        String createEventsTable = "CREATE TABLE " + TABLE_EVENTS + " (" +
                EVENT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                EVENT_NAME + " TEXT NOT NULL, " +
                EVENT_DATE + " TEXT NOT NULL, " +
                EVENT_DESCRIPTION + " TEXT NOT NULL, " +
                EVENT_CATEGORY + " TEXT NOT NULL DEFAULT 'General')";

        db.execSQL(createUsersTable);
        db.execSQL(createEventsTable);
    }

    // Updates the existing database when the database version changes.
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        if (oldVersion < 2) {
            db.execSQL(
                    "ALTER TABLE " + TABLE_EVENTS +
                            " ADD COLUMN " + EVENT_CATEGORY +
                            " TEXT NOT NULL DEFAULT 'General'"
            );
        }
    }

    // Hashes a password before it is stored or compared.
    private String hashPassword(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");

            byte[] encodedHash = digest.digest(
                    password.getBytes(StandardCharsets.UTF_8)
            );

            StringBuilder hexString = new StringBuilder();

            for (byte b : encodedHash) {
                String hex = Integer.toHexString(0xff & b);

                if (hex.length() == 1) {
                    hexString.append('0');
                }

                hexString.append(hex);
            }

            return hexString.toString();

        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Unable to hash password.", e);
        }
    }

    // Adds a new user account to the database.
    public boolean addUser(String username, String password) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(USERNAME, username.trim());
        values.put(PASSWORD, hashPassword(password));

        long result = db.insert(TABLE_USERS, null, values);

        return result != -1;
    }

    // Checks whether the username and password match an account.
    public boolean checkUser(String username, String password) {

        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT " + PASSWORD +
                        " FROM " + TABLE_USERS +
                        " WHERE " + USERNAME + "=?",
                new String[]{username.trim()}
        );

        boolean validUser = false;

        if (cursor.moveToFirst()) {

            String storedPassword = cursor.getString(0);
            String hashedPassword = hashPassword(password);

            // Normal login for accounts using hashed passwords.
            if (storedPassword.equals(hashedPassword)) {
                validUser = true;
            }

            // Allows an older account that used a plain-text password
            // to log in once, then upgrades it to a hashed password.
            else if (storedPassword.equals(password)) {

                ContentValues values = new ContentValues();
                values.put(PASSWORD, hashedPassword);

                db.update(
                        TABLE_USERS,
                        values,
                        USERNAME + "=?",
                        new String[]{username.trim()}
                );

                validUser = true;
            }
        }

        cursor.close();

        return validUser;
    }

    // Adds a new event to the event table.
    public boolean addEvent(
            String name,
            String date,
            String description,
            String category) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(EVENT_NAME, name.trim());
        values.put(EVENT_DATE, date.trim());
        values.put(EVENT_DESCRIPTION, description.trim());
        values.put(EVENT_CATEGORY, category.trim());

        long result = db.insert(TABLE_EVENTS, null, values);

        return result != -1;
    }

    // Reads all events from the database.
    public Cursor getAllEvents() {

        SQLiteDatabase db = this.getReadableDatabase();

        return db.rawQuery(
                "SELECT * FROM " + TABLE_EVENTS +
                        " ORDER BY " + EVENT_DATE + " ASC",
                null
        );
    }

    // Returns events sorted by date.
    public Cursor getEventsSortedByDate() {

        SQLiteDatabase db = this.getReadableDatabase();

        return db.rawQuery(
                "SELECT * FROM " + TABLE_EVENTS +
                        " ORDER BY " + EVENT_DATE + " ASC",
                null
        );
    }

    // Returns events sorted alphabetically by category.
    public Cursor getEventsSortedByCategory() {

        SQLiteDatabase db = this.getReadableDatabase();

        return db.rawQuery(
                "SELECT * FROM " + TABLE_EVENTS +
                        " ORDER BY " + EVENT_CATEGORY + " ASC, " +
                        EVENT_DATE + " ASC",
                null
        );
    }

    // Returns only events that match a selected category.
    public Cursor getEventsByCategory(String category) {

        SQLiteDatabase db = this.getReadableDatabase();

        return db.rawQuery(
                "SELECT * FROM " + TABLE_EVENTS +
                        " WHERE " + EVENT_CATEGORY + "=?" +
                        " ORDER BY " + EVENT_DATE + " ASC",
                new String[]{category.trim()}
        );
    }

    // Updates an existing event.
    public boolean updateEvent(
            int id,
            String name,
            String date,
            String description,
            String category) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(EVENT_NAME, name.trim());
        values.put(EVENT_DATE, date.trim());
        values.put(EVENT_DESCRIPTION, description.trim());
        values.put(EVENT_CATEGORY, category.trim());

        int result = db.update(
                TABLE_EVENTS,
                values,
                EVENT_ID + "=?",
                new String[]{String.valueOf(id)}
        );

        return result > 0;
    }

    // Deletes an event from the database.
    public boolean deleteEvent(int id) {

        SQLiteDatabase db = this.getWritableDatabase();

        int result = db.delete(
                TABLE_EVENTS,
                EVENT_ID + "=?",
                new String[]{String.valueOf(id)}
        );

        return result > 0;
    }
}