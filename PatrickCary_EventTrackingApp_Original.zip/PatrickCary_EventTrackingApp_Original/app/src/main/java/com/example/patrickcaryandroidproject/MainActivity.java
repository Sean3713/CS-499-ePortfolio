package com.example.patrickcaryandroidproject;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

// This screen allows the user to log in or create a new account.
public class MainActivity extends AppCompatActivity {

    private EditText editUsername;
    private EditText editPassword;
    private Button buttonLogin;
    private Button buttonCreateAccount;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Connects Java variables to the XML screen items.
        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);
        buttonLogin = findViewById(R.id.buttonLogin);
        buttonCreateAccount = findViewById(R.id.buttonCreateAccount);

        // Creates the database helper object.
        databaseHelper = new DatabaseHelper(this);

        // Checks the database when the user clicks Log In.
        buttonLogin.setOnClickListener(view -> {
            String username = editUsername.getText().toString().trim();
            String password = editPassword.getText().toString().trim();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please enter a username and password.", Toast.LENGTH_SHORT).show();
            } else {
                boolean userExists = databaseHelper.checkUser(username, password);

                if (userExists) {
                    Toast.makeText(this, "Login successful.", Toast.LENGTH_SHORT).show();

                    // Sends the user to the event grid screen after login.
                    Intent intent = new Intent(MainActivity.this, EventGridActivity.class);
                    startActivity(intent);
                } else {
                    Toast.makeText(this, "Incorrect login. Create an account if you are new.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Creates a new account and saves it in the database.
        buttonCreateAccount.setOnClickListener(view -> {
            String username = editUsername.getText().toString().trim();
            String password = editPassword.getText().toString().trim();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please enter a username and password.", Toast.LENGTH_SHORT).show();
            } else {
                boolean accountCreated = databaseHelper.addUser(username, password);

                if (accountCreated) {
                    Toast.makeText(this, "Account created. You can now log in.", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Account already exists or could not be created.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}