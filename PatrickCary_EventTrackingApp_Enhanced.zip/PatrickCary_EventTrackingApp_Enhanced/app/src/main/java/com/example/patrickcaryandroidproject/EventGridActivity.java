package com.example.patrickcaryandroidproject;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

// This screen lets the user create, read, update, delete, filter, and sort events.
public class EventGridActivity extends AppCompatActivity {

    private EditText editEventId;
    private EditText editEventName;
    private EditText editEventDate;
    private EditText editEventDescription;
    private EditText editEventCategory;

    private Button buttonAddEvent;
    private Button buttonViewEvents;
    private Button buttonUpdateEvent;
    private Button buttonDeleteEvent;
    private Button buttonFilterCategory;
    private Button buttonSortDate;
    private Button buttonSortCategory;
    private Button buttonSmsSettings;

    private TextView textEventList;

    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_grid);

        databaseHelper = new DatabaseHelper(this);

        editEventId = findViewById(R.id.editEventId);
        editEventName = findViewById(R.id.editEventName);
        editEventDate = findViewById(R.id.editEventDate);
        editEventDescription = findViewById(R.id.editEventDescription);
        editEventCategory = findViewById(R.id.editEventCategory);

        buttonAddEvent = findViewById(R.id.buttonAddEvent);
        buttonViewEvents = findViewById(R.id.buttonViewEvents);
        buttonUpdateEvent = findViewById(R.id.buttonUpdateEvent);
        buttonDeleteEvent = findViewById(R.id.buttonDeleteEvent);
        buttonFilterCategory = findViewById(R.id.buttonFilterCategory);
        buttonSortDate = findViewById(R.id.buttonSortDate);
        buttonSortCategory = findViewById(R.id.buttonSortCategory);
        buttonSmsSettings = findViewById(R.id.buttonSmsSettings);

        textEventList = findViewById(R.id.textEventList);

        buttonAddEvent.setOnClickListener(view -> addEvent());

        buttonViewEvents.setOnClickListener(view -> viewEvents());

        buttonUpdateEvent.setOnClickListener(view -> updateEvent());

        buttonDeleteEvent.setOnClickListener(view -> deleteEvent());

        buttonFilterCategory.setOnClickListener(view -> filterByCategory());

        buttonSortDate.setOnClickListener(view -> sortByDate());

        buttonSortCategory.setOnClickListener(view -> sortByCategory());

        buttonSmsSettings.setOnClickListener(view -> {
            Intent intent =
                    new Intent(EventGridActivity.this, SmsPermissionActivity.class);

            startActivity(intent);
        });
    }

    // Adds a new event to the database.
    private void addEvent() {

        String name =
                editEventName.getText().toString().trim();

        String date =
                editEventDate.getText().toString().trim();

        String description =
                editEventDescription.getText().toString().trim();

        String category =
                editEventCategory.getText().toString().trim();

        if (name.isEmpty()
                || date.isEmpty()
                || description.isEmpty()
                || category.isEmpty()) {

            Toast.makeText(
                    this,
                    "Please enter event name, date, description, and category.",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        boolean inserted =
                databaseHelper.addEvent(
                        name,
                        date,
                        description,
                        category
                );

        if (inserted) {

            Toast.makeText(
                    this,
                    "Event added.",
                    Toast.LENGTH_SHORT
            ).show();

            clearInputs();
            viewEvents();

        } else {

            Toast.makeText(
                    this,
                    "Event could not be added.",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    // Shows all events from the database.
    private void viewEvents() {

        Cursor cursor = databaseHelper.getAllEvents();

        displayEvents(cursor, "No events found.");
    }

    // Sorts all events by date.
    private void sortByDate() {

        Cursor cursor =
                databaseHelper.getEventsSortedByDate();

        displayEvents(
                cursor,
                "No events found."
        );
    }

    // Sorts all events by category.
    private void sortByCategory() {

        Cursor cursor =
                databaseHelper.getEventsSortedByCategory();

        displayEvents(
                cursor,
                "No events found."
        );
    }

    // Filters the event list using the category entered by the user.
    private void filterByCategory() {

        String category =
                editEventCategory
                        .getText()
                        .toString()
                        .trim();

        if (category.isEmpty()) {

            Toast.makeText(
                    this,
                    "Enter a category to filter events.",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        Cursor cursor =
                databaseHelper.getEventsByCategory(category);

        displayEvents(
                cursor,
                "No events found in category: " + category
        );
    }

    // Displays events returned by a database query.
    private void displayEvents(
            Cursor cursor,
            String emptyMessage) {

        if (cursor == null) {

            textEventList.setText(
                    "Unable to load events."
            );

            return;
        }

        if (cursor.getCount() == 0) {

            textEventList.setText(emptyMessage);

            cursor.close();

            return;
        }

        StringBuilder builder =
                new StringBuilder();

        while (cursor.moveToNext()) {

            builder
                    .append("ID: ")
                    .append(cursor.getInt(0))
                    .append("\n");

            builder
                    .append("Event: ")
                    .append(cursor.getString(1))
                    .append("\n");

            builder
                    .append("Date: ")
                    .append(cursor.getString(2))
                    .append("\n");

            builder
                    .append("Description: ")
                    .append(cursor.getString(3))
                    .append("\n");

            builder
                    .append("Category: ")
                    .append(cursor.getString(4))
                    .append("\n\n");
        }

        textEventList.setText(
                builder.toString()
        );

        cursor.close();
    }

    // Updates an event by using its ID number.
    private void updateEvent() {

        String idText =
                editEventId
                        .getText()
                        .toString()
                        .trim();

        String name =
                editEventName
                        .getText()
                        .toString()
                        .trim();

        String date =
                editEventDate
                        .getText()
                        .toString()
                        .trim();

        String description =
                editEventDescription
                        .getText()
                        .toString()
                        .trim();

        String category =
                editEventCategory
                        .getText()
                        .toString()
                        .trim();

        if (idText.isEmpty()
                || name.isEmpty()
                || date.isEmpty()
                || description.isEmpty()
                || category.isEmpty()) {

            Toast.makeText(
                    this,
                    "Please enter ID, name, date, description, and category.",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        try {

            int id =
                    Integer.parseInt(idText);

            boolean updated =
                    databaseHelper.updateEvent(
                            id,
                            name,
                            date,
                            description,
                            category
                    );

            if (updated) {

                Toast.makeText(
                        this,
                        "Event updated.",
                        Toast.LENGTH_SHORT
                ).show();

                clearInputs();
                viewEvents();

            } else {

                Toast.makeText(
                        this,
                        "Event not found.",
                        Toast.LENGTH_SHORT
                ).show();
            }

        } catch (NumberFormatException e) {

            Toast.makeText(
                    this,
                    "Event ID must be a number.",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    // Deletes an event by using its ID number.
    private void deleteEvent() {

        String idText =
                editEventId
                        .getText()
                        .toString()
                        .trim();

        if (idText.isEmpty()) {

            Toast.makeText(
                    this,
                    "Please enter the event ID.",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        try {

            int id =
                    Integer.parseInt(idText);

            boolean deleted =
                    databaseHelper.deleteEvent(id);

            if (deleted) {

                Toast.makeText(
                        this,
                        "Event deleted.",
                        Toast.LENGTH_SHORT
                ).show();

                clearInputs();
                viewEvents();

            } else {

                Toast.makeText(
                        this,
                        "Event not found.",
                        Toast.LENGTH_SHORT
                ).show();
            }

        } catch (NumberFormatException e) {

            Toast.makeText(
                    this,
                    "Event ID must be a number.",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    // Clears the typing boxes after an action is finished.
    private void clearInputs() {

        editEventId.setText("");
        editEventName.setText("");
        editEventDate.setText("");
        editEventDescription.setText("");
        editEventCategory.setText("");
    }
}