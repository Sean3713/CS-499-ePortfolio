// Bring in the DB connection and the Trip schema
const Mongoose = require('./db');
const Trip = require('./travlr');

// Read seed data from JSON file
const fs = require('fs');
const trips = JSON.parse(
    fs.readFileSync('./data/trips.json', 'utf8')
);

// Wait for MongoDB, delete existing records, and insert seed data
const seedDB = async () => {
    if (Mongoose.connection.readyState !== 1) {
        await new Promise((resolve, reject) => {
            Mongoose.connection.once('connected', resolve);
            Mongoose.connection.once('error', reject);
        });
    }

    await Trip.deleteMany({});
    await Trip.insertMany(trips);
};

// Run the seed script, close MongoDB, and exit
seedDB()
    .then(async () => {
        console.log(`${trips.length} trips added successfully`);
        await Mongoose.connection.close();
        process.exit(0);
    })
    .catch(async (err) => {
        console.error('Database seed error:', err);
        await Mongoose.connection.close();
        process.exit(1);
    });
